'''
Program Name: Fifteen.py
Author: Brayden Rhee
Date: January 25, 2025

Description: A 15-puzzle game where players arrange tiles in order by sliding them into a blank space.
'''

import time
import tkinter as tk
from tkinter import messagebox
from graphics import *
from random import shuffle

def position_sorter(p):
    x, y = p.getX(), p.getY()
    if 0 <= x <= 240:
        if 0 <= y <= 220: return 0
        elif 220 < y <= 420: return 4
        elif 420 < y <= 620: return 8
        elif 620 < y <= 840: return 12
    elif 240 < x <= 440:
        if 0 <= y <= 220: return 1
        elif 220 < y <= 420: return 5
        elif 420 < y <= 620: return 9
        elif 620 < y <= 840: return 13
    elif 440 < x <= 640:
        if 0 <= y <= 220: return 2
        elif 220 < y <= 420: return 6
        elif 420 < y <= 620: return 10
        elif 620 < y <= 840: return 14
    elif 640 < x <= 840:
        if 0 <= y <= 220: return 3
        elif 220 < y <= 420: return 7
        elif 420 < y <= 620: return 11
        elif 620 < y <= 840: return 15

def check_after(index, boxes):
    if boxes[index+1] == 'blank':
        boxes[index+1], boxes[index] = boxes[index], 'blank'
        return True
    return False

def check_before(index, boxes):
    if boxes[index-1] == 'blank':
        boxes[index-1], boxes[index] = boxes[index], 'blank'
        return True
    return False

def check_below(index, boxes):
    if boxes[index+4] == 'blank':
        boxes[index+4], boxes[index] = boxes[index], 'blank'
        return True
    return False

def check_above(index, boxes):
    if boxes[index-4] == 'blank':
        boxes[index-4], boxes[index] = boxes[index], 'blank'
        return True
    return False

def checker(p, boxes):
    index = position_sorter(p)
    moved = False

    if index in [0, 1, 2, 4, 5, 6, 8, 9, 10, 12, 13, 14]:
        if check_after(index, boxes):
            moved = True
            

    if index in [1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 15]:
        if check_before(index, boxes):
            moved = True
            

    if index in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]:
        if check_below(index, boxes):
            moved = True
            

    if index in [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]:
        if check_above(index, boxes):
            moved = True

    return moved, boxes

def check_win(boxes, win):
    if boxes == ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', 'blank']:
        win.delete('all')
        positions = [
            (120, 120), (320, 120), (520, 120), (720, 120),
            (120, 320), (320, 320), (520, 320), (720, 320),
            (120, 520), (320, 520), (520, 520), (720, 520),
            (120, 720), (320, 720), (520, 720), (720, 720)
        ]
        for pos in positions:
            img = Image(Point(pos[0], pos[1]), "./gifs/win.gif")
            img.draw(win)
        return True
    return False

def popup(title, message):
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo(title, message)
    root.destroy()

def background_image(win, image_path):
    bg_image = Image(Point(win.getWidth() / 2, win.getHeight() / 2), image_path)
    bg_image.draw(win)

def main():
    win = GraphWin("Fifteen Puzzle Game", 840, 840)
    background_image(win, "./gifs/background.gif")
    
    print("Logs: \nProgram launched.")
    
    boxes = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', 'blank']
    shuffle(boxes)

    def draw_images():
        positions = [
            (120, 120), (320, 120), (520, 120), (720, 120),
            (120, 320), (320, 320), (520, 320), (720, 320),
            (120, 520), (320, 520), (520, 520), (720, 520),
            (120, 720), (320, 720), (520, 720), (720, 720)
        ]

        for idx, pos in enumerate(positions):
            img = Image(Point(pos[0], pos[1]), f"./gifs/{boxes[idx]}.gif")
            img.draw(win)
    
    popup(
        "Welcome!",
        "The 15 puzzle is a sliding puzzle on a 4x4 grid, arranging tiles in order using one empty space.\n\nPress OK to start, and we’ll keep track of your time!"
    )
    draw_images()
    print("Game started.")
    start_time = time.monotonic()    
    print("Time counting module started.\n")
    total_count = 0

    while True:
        if check_win(boxes, win):
            print("\nGame ended.")
            end_time = time.monotonic()
            print("Time counting module stopped.")            
            popup(
                "You Won!",
                f"Total Moves: {total_count}\nTime Played: {int(end_time - start_time)} seconds.\n\nA click on the 'You Won' will stop the program.\nThanks for playing!"
            )
            p = win.getMouse()
            print("Exiting...")
            break
        
        try: p = win.getMouse()
        
        except GraphicsError:
            print("\nError detected. Checking window status...")
            if win.isClosed(): print("Window is closed.\n\nGame ended.")
            else: print("GraphicsError occured.\n\nGame ended.")
            break

        moved, boxes = checker(p, boxes)
        if moved:
            total_count += 1
            current_time = time.monotonic()
            print(f"Action successful. Total count: {total_count} Time: {round((current_time - start_time), 1)}")
            if total_count % 30 == 0:
                print("Optimizing...")
                win.delete('all')
                if (total_count // 60) % 2 == 0:
                    background_image(win, "./gifs/bg_refresh1.gif")
                else:
                    background_image(win, "./gifs/bg_refresh2.gif")
                print("Optimized")
        draw_images()

main()